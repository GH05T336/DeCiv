# TODO

## Big one: convert terrain types!
* Plains to Badlands, Grassland to Wasteland, Snow to Permafrost
* update terrain file
* update resource file
* update improvements file
* check all other files for necessary updates

## Resources
* reduce resources to restore game balance
* convert groundwater to bonus resource

## Units
* power armor: infantry and armor units to add
* mechanized worker
* naval units
* hover drone

## Translation files
* update template
* update existing files to match template

## Natural (Ancient) Wonders
* crashed ISS?
* need pixel art
